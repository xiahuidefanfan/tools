export const Messages = {
  noUpdates: 'No updates are available',
  updatesNotice: 'PMM checks for updates once a day',
  upToDate: 'You are up to date',
};
