export const Messages = {
  availableVersion: 'Available version',
  whatsNew: "What's new", // eslint-disable-line
};
