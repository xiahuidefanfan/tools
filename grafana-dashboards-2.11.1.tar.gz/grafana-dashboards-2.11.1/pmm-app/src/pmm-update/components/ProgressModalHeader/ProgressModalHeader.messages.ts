export const Messages = {
  updateInProgress: 'Upgrade in progress',
  updateFailed: 'Error',
  updateSucceeded: 'Success',
};
