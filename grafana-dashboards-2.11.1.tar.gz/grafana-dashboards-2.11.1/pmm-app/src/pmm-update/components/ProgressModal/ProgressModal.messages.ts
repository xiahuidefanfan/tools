export const Messages = {
  copyToClipboard: 'Copy to clipboard',
  updateSuccessNotice: 'PMM has been successfully upgraded to version',
};
