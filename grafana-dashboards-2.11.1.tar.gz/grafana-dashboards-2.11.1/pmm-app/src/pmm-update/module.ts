import { PanelPlugin } from '@grafana/data';
import { UpdatePanel } from './UpdatePanel';

export const plugin = new PanelPlugin<{}, {}>(UpdatePanel);
