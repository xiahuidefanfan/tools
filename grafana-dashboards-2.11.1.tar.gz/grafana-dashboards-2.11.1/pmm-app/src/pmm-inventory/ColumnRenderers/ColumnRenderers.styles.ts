import { css } from 'emotion';

export const detailsWrapper = css`
  display: flex;
  flex-direction: column;
`;
