export class ConfigCtrl {
  static template = '<h3 class="page-heading">PMM App</h3>';
}
