export enum TabKeys {
  kubernetes = 'kubernetes',
  xtradb = 'xtradb',
}
