import { CSSProperties } from 'react';

export const styles = {
  disabled: {
    opacity: 0.6,
    pointerEvents: 'none',
  } as CSSProperties,
};
