export interface AddClusterButtonProps {
  label: string;
  action: () => void;
}
