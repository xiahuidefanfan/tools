export const DATABASE_OPTIONS = [{
  value: 'mysql',
  label: 'MySQL',
}];
