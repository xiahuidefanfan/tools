export const kubernetesOptionsStub = [
  {
    value: 'Test Cluster 1',
    label: 'Test Cluster 1',
  },
  {
    value: 'Test Cluster 2',
    label: 'Test Cluster 2',
  },
];

export const setVisibleStub = jest.fn();
export const onXtraDBAddedStub = jest.fn();
