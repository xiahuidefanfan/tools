import { Kubernetes } from '../Kubernetes/Kubernetes.types';

export type AddXtraDBAction = (xtradbCluster: XtraDBCluster) => void;
export type GetXtraDBClustersAction = () => void;

export interface XtraDBProps {
  kubernetes: Kubernetes[];
}

export interface XtraDBCluster {
  clusterName: string;
  kubernetesClusterName: string;
  databaseType: string;
}

export interface XtraDBClusterAPI {
  kubernetes_cluster_name: string;
  name: string;
  params: XtraDBClusterParamsAPI;
}

interface XtraDBClusterParamsAPI {
  cluster_size: number;
  pxc: XtraDBClusterContainerAPI;
  proxysql: XtraDBClusterContainerAPI;
}

interface XtraDBClusterContainerAPI {
  compute_resources: XtraDBComputeResourcesAPI;
}

interface XtraDBComputeResourcesAPI {
  cpu_m: number;
  memory_bytes: number;
}
