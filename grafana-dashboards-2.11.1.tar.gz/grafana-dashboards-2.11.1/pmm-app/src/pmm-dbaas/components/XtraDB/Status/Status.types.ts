export interface StatusProps {
  active: boolean;
  label: string;
  dataQa?: string;
}
