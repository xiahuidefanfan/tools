export interface PTSummaryRequest {
  node_id: string;
}

export interface PTSummaryResponse {
  action_id: string;
  pmm_agent_id: string;
}
