export const Messages = {
  runDbChecks: 'Run DB checks',
};
