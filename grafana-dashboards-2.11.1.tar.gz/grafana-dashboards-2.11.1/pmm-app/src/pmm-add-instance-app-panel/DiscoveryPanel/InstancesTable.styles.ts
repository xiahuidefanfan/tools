import { css } from 'emotion';

export const styles = {
  tableWrapper: css`
    margin-top: 10px;
  `,
};
