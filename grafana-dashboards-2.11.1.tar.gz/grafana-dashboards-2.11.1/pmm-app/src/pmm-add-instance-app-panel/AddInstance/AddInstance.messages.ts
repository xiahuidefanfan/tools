export const Messages = {
  form: {
    trackingOptions: {
      none: 'Don\'t track',
      pgStatements: 'PG Stat Statements',
      pgMonitor: 'PG Stat Monitor',
    },
    labels: {
      trackingOptions: 'Stat tracking options',
    },
  },
};
