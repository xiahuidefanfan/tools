import { css } from 'emotion';

export const styles = {
  scrollbar: css`
    .simplebar-scrollbar::before {
      background: white !important;
    }
  `,
};
