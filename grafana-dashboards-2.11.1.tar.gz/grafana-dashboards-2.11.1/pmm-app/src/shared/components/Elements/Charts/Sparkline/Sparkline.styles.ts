import { css } from 'emotion';

export const styles = {
  graphWrapper: css`
    background: transparent;
    borderBottom: 1px solid grey;
`,
};
