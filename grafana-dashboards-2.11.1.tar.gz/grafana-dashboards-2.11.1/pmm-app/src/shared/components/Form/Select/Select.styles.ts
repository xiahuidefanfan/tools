import { css } from 'emotion';

export const styles = {
  select: css`
  width: 100%
  height: 40px
  `,
};
