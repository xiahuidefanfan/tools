import { css } from 'emotion';

export const Styling = {
  button: css`
    color: white !important;
    background-color: #212327 !important;
    border-radius: 0px !important;
    border: 1px solid #212327 !important;
    height: 36px !important;
  `,
};
