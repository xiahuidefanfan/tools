export const GUI_DOC_URL = 'https://www.percona.com/doc/percona-monitoring-and-management/2.x/manage/server-admin-gui.html';
export const DATA_RETENTION_URL = 'https://www.percona.com/doc/percona-monitoring-and-management/2.x/faq.html#how-to-control-data-retention-for-pmm';
