export const TERMS_OF_SERVICE_URL = 'https://per.co.na/pmm/platform-terms';

export const PRIVACY_POLICY_URL = 'https://per.co.na/pmm/platform-privacy';
