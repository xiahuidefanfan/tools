export const SECONDS = 60;
export const MINUTES = 60;
export const HOURS = 24;
export const SECONDS_IN_DAY = SECONDS * MINUTES * HOURS;
export const MINUTES_IN_HOUR = MINUTES * HOURS;
export const MIN_DAYS = 1;
export const MAX_DAYS = 3650;
