export const Messages = {
  search: {
    placeholder: 'Search by...',
  },
};
