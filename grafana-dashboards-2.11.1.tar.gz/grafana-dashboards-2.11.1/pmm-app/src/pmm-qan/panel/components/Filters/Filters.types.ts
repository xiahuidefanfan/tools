export interface FiltersContainerProps {
  contextActions: any;
  form: any;
  filters: any;
  disabled?: boolean;
}
