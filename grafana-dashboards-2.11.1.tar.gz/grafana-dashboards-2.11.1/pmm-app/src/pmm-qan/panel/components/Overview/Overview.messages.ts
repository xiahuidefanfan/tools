export const Messages = {
  table: {
    noData: 'No queries available for this combination of filters in the selected time frame',
  },
};
