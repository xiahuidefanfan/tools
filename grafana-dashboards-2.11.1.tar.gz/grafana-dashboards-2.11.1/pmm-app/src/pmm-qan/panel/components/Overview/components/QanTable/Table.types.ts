export interface SelectedTableRows<T> {
  id: string;
  original: T;
}
