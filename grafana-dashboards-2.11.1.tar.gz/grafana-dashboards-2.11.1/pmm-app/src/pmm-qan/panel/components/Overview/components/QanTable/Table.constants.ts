export const NAVIGATION_HEIGHT = 70;
