import { Messages } from '../Details.messages';

export const TableTabs = {
  table: Messages.tabs.tables.sections.table,
  indexes: Messages.tabs.tables.sections.indexes,
  status: Messages.tabs.tables.sections.status,
};
