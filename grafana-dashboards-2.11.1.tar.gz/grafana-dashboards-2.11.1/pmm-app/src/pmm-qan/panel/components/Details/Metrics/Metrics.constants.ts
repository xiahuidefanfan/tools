import { Messages } from '../Details.messages';

export const MetricsTabs = {
  distribution: Messages.tabs.details.sections.timeDistribution,
  metrics: Messages.tabs.details.sections.metrics,
};
