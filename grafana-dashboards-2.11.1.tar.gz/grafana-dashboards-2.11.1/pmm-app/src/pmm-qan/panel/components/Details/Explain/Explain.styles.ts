import { css } from 'emotion';

export const styles = {
  collapse: css`
    background: transparent !important;
    margin-bottom: 10px !important;
    border: none !important;
    color: white !important;
    text-color: white !important;
  `,
  panel: css`
    background: transparent !important;
    margin-bottom: 10px !important;
    border: none !important;
    color: white !important;
    text-color: white !important;
  `,
};
