export const TabKeys = {
  details: 'details',
  examples: 'examples',
  explain: 'explain',
  tables: 'tables',
};
