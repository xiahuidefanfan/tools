export { DetailsSection as Details } from './Details';
