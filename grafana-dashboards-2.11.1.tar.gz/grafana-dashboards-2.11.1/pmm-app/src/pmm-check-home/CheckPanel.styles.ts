import { css } from 'emotion';

export const panel = css`
  display: flex;
  height: 100%;
  justify-content: center;
  align-items: center;
`;
